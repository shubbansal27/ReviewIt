package test4;

public class room {
	
	int id; 
	float status, rate; 
	room r;
	
	public void displayDetails()
	{
		
	}
	
	public void bookRoom()
	{
		
	}

}
