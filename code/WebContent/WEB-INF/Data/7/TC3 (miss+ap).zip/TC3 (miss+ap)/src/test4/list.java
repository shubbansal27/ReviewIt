package test4;

public class list {
	
	int listId;
	String listDate;  
	
	
	public void generateListssss()  
	{
		
	}
	
	public void showList()
	{
		
	}
	

}
