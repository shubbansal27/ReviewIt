package test4;

public class cottage extends room {
	
	int noOfBeds;
	
	public void displayDetails()
	{
		
	}
	
	public int bookRom()  
	{
		return 8;
	}

}
