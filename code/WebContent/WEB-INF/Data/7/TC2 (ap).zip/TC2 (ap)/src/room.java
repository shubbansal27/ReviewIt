package test4;

public class room {
	
	int id; 
	float status, rate; 
	
	
	public void displayDetails()
	{
		
	}
	
	public void bookRoom()
	{
		
	}

}
