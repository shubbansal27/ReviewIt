package test1;

public class Class2 {
	
	int Attribute1;
	float Attribute2;
	Class1 c1 = new Class1();	
	public int Operation1()
	{
		return 0;
	}
	

}
