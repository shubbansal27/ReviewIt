package test1;

public class Class4 {

	String attr4;
	Class2 c= new Class2();
	public boolean class4_Operation1()
	{
		return false;
	}
		
}
