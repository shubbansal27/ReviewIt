package test1;

public class Class5 extends Class2 {
	
	float temp;
	Class1 c1 = new Class1();
	public int temp_function()
	{
		return 34;
	}

}
