package test1;

public class Class3 {

	float attr3;
	Class2 c= new Class2();
	public boolean Opr(int a, float b)
	{
		return true;
	}
	
}
