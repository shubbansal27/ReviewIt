package test4;

import java.util.List;

public class summary {
	
	int summaryID;
	String summaryDate; 
	String bookDetails; 
	int id;
	float clientId; 
	int roomList;
	String cFname;
	String cLname;
	String cemail;
	Double cphoneNo;
	String address;
	String DOB;
	String comment;
	String payType;
	room r1=new room();
	
	public void generateSummary(String id, Long datewww)
	{
		
	}
	
	public void showSummary()
	{
		
	}
	
	public List<String> generateCleanList()
	{
		return null;
	}
	
	public String generateBookingSummary()
	{
		return "successful";
	}
	
	public void reserve()
	{
		
	}

}
