package test4;

public class meetingRooom extends room {
	
	int capacity;

}
