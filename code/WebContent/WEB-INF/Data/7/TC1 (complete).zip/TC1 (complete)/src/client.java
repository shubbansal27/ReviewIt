public class client {
	public int clienID;
	public String name;
	public String phoneNO;
	public String email;
	
	public String getDetails() {}
	public void showDetails() {}
	public int makeReservation(int id) {
		reservation r = new reservation();
		r.reserve();
		
		
	
	}
	public int cancelReservation(int id) {}
}
