public class list{
	public int listID;
	public Date Date;
	public int rooms;
	
	public void generateList() {
		room rm = new room();
	}
	public void showList() {
		room rm = new room();
	}
}