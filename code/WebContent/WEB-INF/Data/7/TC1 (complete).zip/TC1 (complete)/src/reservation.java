public class reservation {
	public int id;
	public int clientID;
	public Date reservationDate;
	public int roomList;
	
	public String reserve() {
		client cl = new client();
		
	}
	public void display(int id) {
		room rm = new room();
	}
	public int cancel() {}
}
