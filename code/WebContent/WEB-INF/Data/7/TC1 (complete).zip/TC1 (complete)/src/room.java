public class room {
	public int id;
	public int status;
	public float rate;
	
	public void displayDetails(){ 
		timer tm = new timer();
		list l = new list();
	}
	public void bookRoom(){}
}
