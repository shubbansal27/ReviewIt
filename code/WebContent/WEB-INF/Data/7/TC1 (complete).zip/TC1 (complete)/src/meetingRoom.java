public class meetingRoom extends room {
	public int capacity;
	
	public void displayDetails(String type) {}
	public void bookRoom() {}
}