public class cottage extends room {
	public int noOfBeds;
	
	public void displayDetails() {
	
	}
	
	public void bookRoom() {
	
	}
}
