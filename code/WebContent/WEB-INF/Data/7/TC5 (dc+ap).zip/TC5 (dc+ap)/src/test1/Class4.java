package test1;

public class Class4 {

	String class4;
	Class2 c= new Class2();
	public boolean class4_Operation1()
	{
		return false;
	}
	
	public void Operation1() 
	{
		
	}
	
	public float Operation2(int a, String b)
	{
		return 3.4f;
	}
	
	private int Operation3()
	{
		return 2;
	}
	
	public int Operation4(double m, double n) 
	{
		return 0; 
	}
	
	public void Operation5()
	{
		
	}
	
	public String Operation6(String s)
	{
		return "ooad";
	}
	
	protected double Operation7() 
	{
		return 44;
	}
	
	public void Operation8(int s1)
	{
		
	}
	
	public int Operation9()
	{
		return 7;
	}
	
	public void Operation10()
	{
		
	}
	
	public void Operation11()
	{
		
	}
	
	public String Operation12()
	{
		return "BITS";
	}
	
	public Long Operation13()  
	{
		return (long) 14;
	}
	
	public boolean Operation15() 
	{
		return false;
	}
	
	public void Operation14()
	{
		
	}
	
	
}
