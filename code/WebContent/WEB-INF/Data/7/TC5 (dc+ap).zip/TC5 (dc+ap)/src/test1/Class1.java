package test1;

public class Class1 {

	String name;
	String gender;
	String contactNumber;
	
	public boolean get_deatils(int n, String m)
	{
		return true;
	}
	
	public String display()
	{
		System.out.println("apple");
		return "";
	}
}
