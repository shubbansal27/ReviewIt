package test1;

public class Class5 extends Class2 {
	
	float temp;
	int atr1;
	float atr2;
	String atr3;
	float atr4;
	int atr5;
	float atr6;
	String Attribute7;
	boolean Attribute8;
	boolean Attribute9;
	int Attribute10;
	float Attribute11;
	String Attribute12;
	String Attribute13;
	double Attribute14;
	boolean Attribute15;
	long Attribute16;
	int Attribute17;
	boolean Attribute18;
	String Attribute19;
	String Attribute20;

	Class1 c1 = new Class1();
	public int temp_function()
	{
		return 34;
	}

}
