class Manpreet1 {
	private int id;
	private String name;
	
	public void getDetails() {}
	public void setDetails(int id, String name) {}
}

public class Manpreet2 {
	public int cid;
	public String cname;
	
	public void getDetails() {}
	public void setDetails(int cid, String cname) {}
}

class Manpreet3 {
	String dname;
	
	public void getDetails() {}
	public void setDetails(String name) {}
}

class Manpreet4 {
	public int fid;
	public String fname;
	
	public void getDetails() {}
	public void setDetails(int fid, String fname) {}
}