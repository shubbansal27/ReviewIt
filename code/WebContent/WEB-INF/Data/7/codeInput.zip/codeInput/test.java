class student {
	private int id;
	private String name;
	
	public void getDetails() {}
	public void setDetails(int id, String name) {}
}

public class course {
	public int cid;
	public String cname;
	
	public void getDetails() {
		student st = new student();
	}
	public void setDetails(int cid, String cname) {}
}

class department {
	String dname;
	
	public void getDetails() {}
	public void setDetails(String name) {
		student st = new student();
		faculty fc = new faculty();
	}
	
}

class faculty {
	public int fid;
	public String fname;
	
	public void getDetails() {}
	public void setDetails(int fid, String fname) {}
}