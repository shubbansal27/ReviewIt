public class reservation {
	public int id;
	public int clientID;
	public Date reservationDate;
	public int roomList;
	
	public String reserve() {
	
		room rm = new room();
	}
	public void display(int id) {
		
	}
	
	public int cancel() {
	
	}
}
