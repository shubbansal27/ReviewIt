public class meetingRoom {
	public int capacity;
	
	public void displayDetails(String type) {}
	public void bookRoom(int f) {}
}