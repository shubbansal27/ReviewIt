public class cottage extends room {
	public int noOfBeds;
	
	public void displayDetails() {
	
	}
	
	public int bookRoom() {
	
	}

	public void testRoom() {
	
	}
}
