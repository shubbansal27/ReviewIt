public class client {
	public int clienID;
	public String name;
	public String phoneNO;
	public String email;
	
	public void showDetails() {

	}
	
	public int makeReservation(int id) {
		reservation r = new reservation();
		r.reserve();
	}

	public String getDetails() {

	}

	public int cancelReservation(int id) {

	}
}
