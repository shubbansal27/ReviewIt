import java.util.List;

public class timer {
	
	public time timet;
	
	public List<String> generateCleanList() { 
		
		list ls = new list();

	}
	private String generateBookingSummary() {

	}
}

private class summary {
	protected int summaryID;
	public Date summaryDate;
	protected String bookingDetails;
	
	public void generateSummary(String id, Date d) {
		
	}

	public void showSummary() {
		
	}
}

