package test4;

import java.util.List;

private class summary {
	
	float summaryID;
	String summaryDate;
	String bookDetails; 
	int id;
	float xx;
	float clientId;
	int roomList;
	String cFname;
	String cLname;
	String cemail;
	Double cphoneNo; 
	String address;
	String DOB;
	String comment;
	String payType;
	String cmt;
	room r1=new room();
	
	private void generateSummary(String id, Long datewww) 
	{
		timer t = new timer();
	}
	
	public void showSummary()
	{
		reservation r = new reservation();
	}
	
	public List<String> generateCleanList()
	{
		return null;
	}
	
	public String generateBookingSummary()
	{
		return "successful";
	}
	
	public void reserve()
	{
		
	}
	
	
}
