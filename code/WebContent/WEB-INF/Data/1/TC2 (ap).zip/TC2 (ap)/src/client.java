package test4;

public class client {
	
	int clientID;
	String name;
	String phoneNO;
	protected String email;  
	summary sum1;
	
	public String getDetails()
	{
		return "hello";
	}
	
	public void showDetails()
	{
		
	}
	
	public int makeReservation(int id)
	{
		return 0;
	}
	
	public int cancelReservation(int id,int amount) 
	{
		return 5;
	}

}
