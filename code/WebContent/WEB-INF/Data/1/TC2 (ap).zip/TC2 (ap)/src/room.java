package test4;

public class room {
	
	int id; 
	float status;
	float rate; 
	
	
	public void displayDetails()
	{
		
	}
	
	public void bookRoom()
	{
		
	}

}
