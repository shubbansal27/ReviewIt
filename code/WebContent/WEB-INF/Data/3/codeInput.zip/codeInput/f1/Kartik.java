class Kartik1 {
	private int id;
	private String name;
	
	public void getDetails() {}
	public void setDetails(int id, String name) {}
}

public class Kartik2 {
	public int cid;
	public String cname;
	
	public void getDetails() {}
	public void setDetails(int cid, String cname) {}
}

class Kartik3 {
	String dname;
	
	public void getDetails() {}
	public void setDetails(String name) {}
}

class Kartik4 {
	public int fid;
	public String fname;
	
	public void getDetails() {}
	public void setDetails(int fid, String fname) {}
}